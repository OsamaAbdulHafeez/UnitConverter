(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a055b55a._.js",
  "static/chunks/node_modules_dc50633d._.js"
],
    source: "dynamic"
});
