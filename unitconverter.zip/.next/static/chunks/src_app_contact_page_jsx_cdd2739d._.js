(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4415212b._.js",
  "static/chunks/node_modules_a3b3614d._.js"
],
    source: "dynamic"
});
